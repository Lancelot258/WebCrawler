class Link {
    String url;
    int depth;

    Link(String url, int depth) {
        this.url = url;
        this.depth = depth;
    }
}